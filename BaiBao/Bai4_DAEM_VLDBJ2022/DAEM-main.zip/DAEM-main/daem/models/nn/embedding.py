import torch
import torch.nn as nn
from torch.nn.utils.rnn import pad_sequence
import math


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=128):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1) / math.sqrt(d_model)
        self.register_buffer('pe', pe)
        self.scale = nn.Parameter(torch.Tensor([1.0]))

    def forward(self, x):
        x = x + self.pe[:x.size(0), :] * self.scale
        return self.dropout(x)
